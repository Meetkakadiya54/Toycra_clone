import Herobanner from "./herobanner";
import Products from "./products";

export default function Alltoys() {
    return (
        <>
            <Herobanner/>
            <Products/>
        </>
    )
}