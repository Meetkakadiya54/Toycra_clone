import Herobanner from "./herobanner";

export default function Bulkorders() {
    return (
        <>
            <Herobanner />
        </>
    )
}